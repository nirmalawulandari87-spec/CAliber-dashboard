/* Laras: asisten AI. Wajah dari logo Chandra Asri (gelombang berlapis), latar dari foto kompleks Cilegon.
   Hubungkan ke backend: isi LARAS.endpoint (POST {message, context} -> {answer, confidence?}). */
const LARAS={name:'Laras',endpoint:null};
let _av=0;
function larasAvatar(px,id){const ys=[26,46,64,82],cols=['#2575b8','#253f7a','#4dbfd9','#2575b8'],c='lc'+(_av++);
 const g=ys.map((y,i)=>`<g class="w w${i+1}"><path d="M0,${y} q15,-9 30,0 t30,0 t30,0 t30,0 t30,0 t30,0 t30,0 t30,0 V120 H0Z" transform="translate(${-i*14},0)" fill="${cols[i]}" stroke="#fff" stroke-width="2.4"/></g>`).join('');
 return `<svg class="av" ${id?`id="${id}"`:''} width="${px}" height="${px}" viewBox="0 0 100 100" role="img" aria-label="Laras"><defs><clipPath id="${c}"><circle cx="50" cy="50" r="48"/></clipPath></defs><g clip-path="url(#${c})"><rect width="100" height="100" fill="#4dbfd9"/>${g}</g></svg>`}
$('#lavw').innerHTML=larasAvatar(48,'lav');$('#favw').innerHTML=larasAvatar(40,'fav');
const SUG=['Ringkas kondisi hari ini','Kenapa Furnace 4 menyimpang?','Bandingkan dengan kemarin','Buat draf laporan shift'];
$('#sugg').innerHTML=SUG.map(s=>`<button>${s}</button>`).join('');
$$('#sugg button').forEach(b=>b.onclick=()=>askLaras(b.textContent));
const esc=s=>s.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])),sleep=ms=>new Promise(r=>setTimeout(r,ms));
function updCtx(){const e=$('#ctx');if(e)e.textContent='Laras membaca: '+(R=='day'?'Harian':R=='week'?'7 hari':'30 hari')+' · '+fmt(DATE,{day:'numeric',month:'short',year:'numeric'})}
function addMsg(who,html,conf){const m=document.createElement('div');m.className='m '+(who=='u'?'u':'a');
 m.innerHTML=(who=='a'?larasAvatar(28):'')+`<div class="b">${who=='u'?esc(html):html}${conf?`<div class="conf"><i></i>Keyakinan ${conf} · berdasarkan data dashboard</div>`:''}</div>`;
 $('#msgs').appendChild(m);$('#msgs').scrollTop=1e6;return m}
function openAI(){$('#ai').classList.add('open');$('#fab').classList.add('hide');updCtx();setTimeout(()=>$('#q').focus(),320)}
function closeAI(){$('#ai').classList.remove('open');$('#fab').classList.remove('hide')}
$('#fab').onclick=openAI;$('#aix').onclick=closeAI;
const dayTot=s=>sum(dayPts(s).a)*2;
function answer(q,ctx){const s=q.toLowerCase(),d=gen(R,DATE),k=KP(d),o={maximumFractionDigits:1},open=A.filter(a=>st[a.id]!='done').length;
 if(ctx){const{i,d:x}=ctx,g=(x.a[i]-x.t[i])/x.t[i]*100;return{h:`<b>${x.f[i]}</b><br>Produksi ${nf(x.a[i])} ton/jam, ${g>=0?'di atas':'di bawah'} target ${nf(Math.abs(g),o)}%. Energi ${x.e[i]} GJ/t.`+(x.e[i]>64?' Energi lebih tinggi dari biasanya; saya sarankan memeriksa beban Furnace 4.':' Semua dalam rentang normal.'),c:'tinggi'}}
 if(/furnace/.test(s))return{h:'Konsumsi energi Furnace 4 naik sekitar 3,8% dari baseline sejak pukul 09:40. Dugaan terkuat: efisiensi burner menurun. Langkah yang saya sarankan:<ul><li>Cek rasio udara-bahan bakar</li><li>Bandingkan suhu stack dengan Furnace 3</li><li>Jadwalkan inspeksi burner sebelum shift malam</li></ul>',c:'sedang'};
 if(/kemarin|bandingkan/.test(s)){const a=dayTot(DATE),b=dayTot(addD(DATE,-1)),p=(a/b-1)*100;return{h:`Total produksi <b>${fmt(DATE,{day:'numeric',month:'short'})}</b>: ${nf(a/1000,o)} kt, ${p>=0?'naik':'turun'} ${nf(Math.abs(p),o)}% dibanding ${fmt(addD(DATE,-1),{day:'numeric',month:'short'})} (${nf(b/1000,o)} kt).`,c:'tinggi'}}
 if(/laporan|draf/.test(s))return{h:`<b>Draf laporan shift · ${fmt(DATE,{day:'numeric',month:'long'})}</b><ul><li>Capaian target ${k[0][1]}, produksi ${k[1][1]}</li><li>Energi rata-rata ${k[2][1]}</li><li>${open} peringatan belum ditangani; prioritas: Furnace 4</li><li>Rekomendasi: inspeksi burner dan penyesuaian laju umpan reaktor</li></ul>`,c:'tinggi'};
 if(/energi/.test(s)){const p=dayPts(DATE),mx=p.e.indexOf(Math.max(...p.e));return{h:`Energi rata-rata ${k[2][1]}. Puncak harian ${p.e[mx]} GJ/t terjadi pukul ${hh(mx)}; di luar jam itu konsumsi stabil.`,c:'tinggi'}}
 if(/ringkas|kondisi|hari ini|ringkasan/.test(s))return{h:`<b>${period()}</b><br>Capaian target ${k[0][1]} (${k[0][2]}), produksi ${k[1][1]}, energi rata-rata ${k[2][1]}. ${open?`Ada ${open} peringatan menunggu tindakan; yang paling mendesak adalah Furnace 4.`:'Semua peringatan sudah ditangani.'}`,c:'tinggi'};
 return{h:'Saya belum bisa menjawab itu di mode demo. Coba salah satu pertanyaan di bawah, atau klik titik pada grafik untuk bertanya tentang jam tertentu.'}}
async function remote(q){const r=await fetch(LARAS.endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:q,context:{range:R,date:DATE,kpis:KP(gen(R,DATE))}})}),j=await r.json();return{h:esc(j.answer).replace(/\n/g,'<br>'),c:j.confidence}}
let busy=false;
async function askLaras(q,ctx){q=(q||'').trim();if(!q||busy)return;busy=true;openAI();addMsg('u',q);
 const t=addMsg('a','<div class="dots"><i></i><i></i><i></i></div>');['lav','fav'].forEach(i=>$('#'+i).classList.add('busy'));
 let r;try{r=LARAS.endpoint?await remote(q):(await sleep(900+Math.random()*500),answer(q,ctx))}catch(e){r={h:'Laras belum bisa menjangkau layanan AI. Coba lagi sebentar.'}}
 t.remove();['lav','fav'].forEach(i=>$('#'+i).classList.remove('busy'));addMsg('a',r.h,r.c);busy=false}
$('#send').onclick=()=>{const v=$('#q').value;$('#q').value='';askLaras(v)};
$('#q').onkeydown=e=>{if(e.key=='Enter')$('#send').click()};
addMsg('a','Halo, saya <b>Laras</b>. Saya membaca data yang sedang tampil di dashboard ini. Ada peringatan terbuka di Furnace 4; mau mulai dari situ?');updCtx();
