
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const P={dash:'<path d="M4 13h6V4H4zM14 20h6V11h-6zM4 20h6v-4H4zM14 7h6V4h-6z"/>',prod:'<path d="M3 21V10l6 4V10l6 4V6h6v15z"/>',energy:'<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',alert:'<path d="M6 8a6 6 0 0112 0c0 7 3 8 3 8H3s3-1 3-8M10 20a2 2 0 004 0"/>',report:'<path d="M6 3h9l4 4v14H6zM14 3v5h5M9 13h7M9 17h7"/>',set:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',menu:'<path d="M4 7h16M4 12h16M4 17h16"/>',ai:'<path d="M21 12a8 8 0 01-11.6 7.1L4 20l1-4.6A8 8 0 1121 12z"/>'};
const svg=k=>`<svg viewBox="0 0 24 24">${P[k]}</svg>`;
const NAV=[['dash','Dashboard Eksekutif'],['prod','Produksi'],['energy','Energi'],['alert','Peringatan AI'],['ai','Asisten Laras'],['report','Laporan']];
$('#nav').innerHTML=`<button data-t="Buka menu" id="tg">${svg('menu')}<span class="lbl">Ciutkan menu</span></button>`+NAV.map(([k,t])=>`<button data-k="${k}" data-t="${t}" class="${k=='dash'?'on':''}">${svg(k)}<span class="lbl">${t}</span></button>`).join('')+`<span class="sp"></span><button data-k="set" data-t="Pengaturan">${svg('set')}<span class="lbl">Pengaturan</span></button>`;
const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(t._);t._=setTimeout(()=>t.classList.remove('show'),2200)};
$('#tg').onclick=()=>{$('#side').classList.toggle('open')};
let names={};NAV.concat([['set','Pengaturan']]).forEach(([k,t])=>names[k]=t);
$$('.nav [data-k]').forEach(b=>b.onclick=()=>go(b.dataset.k));
function go(k){if(k=='ai'){openAI();return}$$('.nav [data-k]').forEach(x=>x.classList.toggle('on',x.dataset.k==k));$('#cur').textContent=names[k];
 if(k=='prod'){leg.energy=false}else if(k=='energy'){leg.target=false;leg.actual=false;leg.energy=true}else{leg.target=leg.actual=leg.energy=true}
 draw();if(k=='alert')$('#alerts').scrollIntoView({behavior:'smooth'});if(['report','set'].includes(k))toast(names[k]+' akan tersedia di tahap berikutnya')}
$$('[data-go]').forEach(a=>a.onclick=()=>go(a.dataset.go));
$('#theme').onclick=()=>{const r=document.documentElement,d=r.dataset.theme=='dark'||(!r.dataset.theme&&matchMedia('(prefers-color-scheme:dark)').matches);r.dataset.theme=d?'light':'dark'};
const tick=()=>$('#clock').textContent=new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'});tick();setInterval(tick,30000);
/* data */
const TODAY='2026-10-01',MIN='2026-01-01',sum=a=>a.reduce((x,y)=>x+y,0),nf=(v,o)=>v.toLocaleString('id-ID',o);let DATE=TODAY,R='day';
const addD=(s,n)=>{const d=new Date(s+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10)};
const fmt=(s,o)=>new Date(s+'T12:00:00Z').toLocaleDateString('id-ID',Object.assign({timeZone:'UTC'},o));
function rng(str){let h=2166136261;for(const c of str){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return()=>{h+=0x6D2B79F5;let t=h;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296}}
const TG=[820,830,840,850,850,860,860,860,850,850,840,840];
function dayPts(s){const r=rng(s),bias=.965+r()*.045,sp=Math.floor(r()*12);return{t:TG,a:TG.map(v=>Math.round(v*(bias+(r()-.5)*.025))),e:TG.map((v,i)=>+(61+r()*3+(i==sp?3:0)).toFixed(1))}}
const hh=i=>String(i*2).padStart(2,'0')+':00';
function gen(rg,end){
 if(rg=='day'){const p=dayPts(end),h=Array.from({length:12},(_,i)=>hh(i));return{l:h,f:h.map(x=>fmt(end,{weekday:'long',day:'numeric',month:'short'})+' · '+x),t:p.t,a:p.a,e:p.e,u:'ton/jam',m:2,dates:[]}}
 const n=rg=='week'?7:30,dates=Array.from({length:n},(_,i)=>addD(end,i-n+1)),pp=dates.map(dayPts);
 return{l:dates.map(s=>rg=='week'?fmt(s,{weekday:'short'})+' '+fmt(s,{day:'numeric'}):fmt(s,{day:'numeric',month:'short'})),f:dates.map(s=>fmt(s,{weekday:'long',day:'numeric',month:'long'})),t:pp.map(p=>sum(p.t)*2),a:pp.map(p=>sum(p.a)*2),e:pp.map(p=>+(sum(p.e)/12).toFixed(1)),u:'ton/hari',m:1,dates}}
const KP=d=>{const ta=sum(d.t)*d.m,ac=sum(d.a)*d.m,p=ac/ta*100,o={maximumFractionDigits:1};return[['Capaian target',nf(p,o)+'%',(p>=100?'▲ ':'▼ ')+nf(Math.abs(p-100),o)+'% dari target',p>=100],['Produksi aktual',nf(ac/1000,o)+' kt',''],['Energi rata-rata',nf(sum(d.e)/d.e.length,o)+' GJ/t','Dalam batas normal',true]]};
const period=()=>R=='day'?fmt(DATE,{weekday:'long',day:'numeric',month:'long',year:'numeric'}):(R=='week'?'7':'30')+' hari hingga '+fmt(DATE,{day:'numeric',month:'long',year:'numeric'});
function uiDate(){$('#dpick').value=DATE;$('#dnext').disabled=DATE>=TODAY;$('#dprev').disabled=DATE<=MIN;$('#psub').textContent=(R=='day'?'Per 2 jam · ':'Per hari · ')+period();$('#dtoday').classList.toggle('on',DATE==TODAY);typeof updCtx=='function'&&updCtx()}
const setRange=r=>{R=r;$$('#range button').forEach(x=>x.classList.toggle('on',x.dataset.r==r))};
const setDate=s=>{if(!s)return;DATE=s>TODAY?TODAY:s<MIN?MIN:s;draw()};
function pick(i){const d=gen(R,DATE);if(R!='day'){const s=d.dates[i];setRange('day');setDate(s);toast('Detail per jam · '+fmt(s,{day:'numeric',month:'long'}))}else askLaras('Ada apa pada '+d.f[i]+'?',{i,d})}
const leg={target:true,actual:true,energy:true},COL={target:'#7aa6d6',actual:'#2575b8',energy:'#4fae8a'},NM={target:'Target produksi',actual:'Produksi aktual',energy:'Konsumsi energi'};

$('#leg').innerHTML=Object.keys(NM).map(k=>`<button data-k="${k}"><i style="background:${COL[k]}"></i>${NM[k]}</button>`).join('');
$$('#leg button').forEach(b=>b.onclick=()=>{leg[b.dataset.k]=!leg[b.dataset.k];draw()});
$$('#range button').forEach(b=>b.onclick=()=>{R=b.dataset.r;$$('#range button').forEach(x=>x.classList.toggle('on',x==b));draw()});
const smooth=p=>{let d=`M${p[0][0]},${p[0][1]}`;for(let i=0;i<p.length-1;i++){const a=p[i-1]||p[i],b=p[i],c=p[i+1],e=p[i+2]||c;d+=`C${b[0]+(c[0]-a[0])/6},${b[1]+(c[1]-a[1])/6} ${c[0]-(e[0]-b[0])/6},${c[1]-(e[1]-b[1])/6} ${c[0]},${c[1]}`}return d};
function draw(){uiDate();const d=gen(R,DATE);
 $('#kpis').innerHTML=KP(d).map(k=>`<div class="kpi"><span>${k[0]}</span><strong>${k[1]}</strong><em class="${k[3]===false?'dn':''}">${k[2]||'&nbsp;'}</em></div>`).join('');
 $$('#leg button').forEach(b=>b.classList.toggle('off',!leg[b.dataset.k]));
 const W=700,H=300,m={l:52,r:48,t:14,b:28},n=d.l.length,x=i=>m.l+i*(W-m.l-m.r)/(n-1);
 const all=[...d.t,...d.a],lo=Math.min(...all),hi=Math.max(...all),pad=(hi-lo)*.25||1;
 const y1=v=>m.t+(1-(v-(lo-pad))/(hi-lo+2*pad))*(H-m.t-m.b),y2=v=>m.t+(1-(v-55)/20)*(H-m.t-m.b);
 let s=`<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" id="sv"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2575b8" stop-opacity=".28"/><stop offset="1" stop-color="#2575b8" stop-opacity="0"/></linearGradient></defs>`;
 for(let i=0;i<=4;i++){const yy=m.t+i*(H-m.t-m.b)/4;s+=`<line x1="${m.l}" x2="${W-m.r}" y1="${yy}" y2="${yy}" stroke="currentColor" opacity=".1"/>`;
  s+=`<text x="${m.l-8}" y="${yy+4}" text-anchor="end" font-size="11" fill="currentColor" opacity=".6">${Math.round(lo-pad+(hi-lo+2*pad)*(1-i/4)).toLocaleString('id-ID')}</text>`;
  if(leg.energy)s+=`<text x="${W-m.r+8}" y="${yy+4}" font-size="11" fill="#4fae8a">${Math.round(75-i*5)}</text>`}
 d.l.forEach((t,i)=>{if(i%Math.ceil(n/8)==0)s+=`<text x="${x(i)}" y="${H-8}" text-anchor="middle" font-size="11" fill="currentColor" opacity=".6">${t}</text>`});
 const pts=a=>a.map((v,i)=>[x(i),y1(v)]);
 if(leg.actual){const p=pts(d.a);s+=`<path d="${smooth(p)}L${p[n-1][0]},${H-m.b}L${p[0][0]},${H-m.b}Z" fill="url(#g)"/>`}
 if(leg.target)s+=`<path d="${smooth(pts(d.t))}" fill="none" stroke="${COL.target}" stroke-width="2.5" stroke-dasharray="6 5" stroke-linecap="round"/>`;
 if(leg.actual)s+=`<path d="${smooth(pts(d.a))}" fill="none" stroke="${COL.actual}" stroke-width="3" stroke-linecap="round"/>`;
 if(leg.energy)s+=`<path d="${smooth(d.e.map((v,i)=>[x(i),y2(v)]))}" fill="none" stroke="${COL.energy}" stroke-width="3" stroke-linecap="round"/>`;
 s+=`<line id="cl" y1="${m.t}" y2="${H-m.b}" stroke="currentColor" opacity="0" stroke-dasharray="3 3"/><rect id="hit" x="0" y="0" width="${W}" height="${H}" fill="transparent"/></svg><div class="tip" id="tip"></div>`;
 $('#chart').innerHTML=s;
 const hit=$('#hit'),sv=$('#sv'),tip=$('#tip'),cl=$('#cl');
 hit.onmousemove=e=>{const r=sv.getBoundingClientRect(),px=(e.clientX-r.left)/r.width*W;let i=Math.round((px-m.l)/((W-m.l-m.r)/(n-1)));i=Math.max(0,Math.min(n-1,i));
  cl.setAttribute('x1',x(i));cl.setAttribute('x2',x(i));cl.style.opacity=.35;
  tip.innerHTML=`<b>${d.f[i]}</b>`+(leg.target?`<div style="color:${COL.target}">Target: ${d.t[i].toLocaleString('id-ID')} ${d.u}</div>`:'')+(leg.actual?`<div style="color:${COL.actual}">Aktual: ${d.a[i].toLocaleString('id-ID')} ${d.u}</div>`:'')+(leg.energy?`<div style="color:${COL.energy}">Energi: ${d.e[i]} GJ/t</div>`:'');
  tip.style.opacity=1;const tx=x(i)/W*r.width;tip.style.left=Math.min(tx+14,r.width-tip.offsetWidth-4)+'px';tip.style.top='10px'};
 hit.onmouseleave=()=>{tip.style.opacity=0;cl.style.opacity=0};hit.style.cursor='pointer';hit.onclick=e=>{const r=sv.getBoundingClientRect(),px=(e.clientX-r.left)/r.width*W;pick(Math.max(0,Math.min(n-1,Math.round((px-m.l)/((W-m.l-m.r)/(n-1))))))}}
/* alerts */
const A=[{id:1,c:'var(--rose)',tag:'Prioritas tinggi',t:'Penyimpangan energi di Furnace 4',m:'Unit Cracker · 14 menit lalu',r:'AI menyarankan memeriksa Furnace 4 karena konsumsi energi sedikit menyimpang (+3,8% dari baseline).',x:'Pola mulai terlihat sejak pukul 09:40. Penyebab paling mungkin: efisiensi burner menurun. Pemeriksaan sekarang dapat mencegah kehilangan sekitar 120 GJ hari ini.'},
{id:2,c:'var(--amber)',tag:'Perlu perhatian',t:'Laju produksi polietilena melambat',m:'Unit Polyolefin · 41 menit lalu',r:'AI menyarankan menyesuaikan laju umpan reaktor; produksi 1,6% di bawah target per jam.',x:'Penurunan terkait suhu umpan yang naik perlahan. Menyesuaikan setpoint dapat mengembalikan laju dalam sekitar 2 jam.'},
{id:3,c:'var(--blue)',tag:'Informasi',t:'Peluang penghematan uap',m:'Utilitas · 1 jam lalu',r:'AI menyarankan menjadwalkan ulang pembersihan boiler ke shift malam untuk menghemat sekitar 2% uap.',x:'Beban uap malam hari lebih rendah, sehingga pembersihan tidak mengganggu produksi.'}];
const st={};let flt='all';
function alerts(){const l=A.filter(a=>flt=='all'||st[a.id]!='done'&&st[a.id]!='gone');
 $('#alerts').innerHTML=l.map(a=>`<article class="al ${st[a.id]=='done'?'done':''} ${st[a.id]=='ex'?'ex':''}" style="--c:${a.c}"><div class="top"><h3>${a.t}</h3><span class="tag">${st[a.id]=='done'?'Ditangani':a.tag}</span></div><div class="meta">${a.m}</div><div class="rec"><svg class="ic" viewBox="0 0 24 24"><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/></svg><span>${a.r}</span></div><div class="more">${a.x}</div><div class="act"><button class="pri" data-a="done" data-i="${a.id}">${st[a.id]=='done'?'Buka kembali':'Tandai ditangani'}</button><button data-a="ex" data-i="${a.id}">${st[a.id]=='ex'?'Sembunyikan detail':'Lihat detail'}</button><button data-a="ask" data-i="${a.id}">Tanya Laras</button></div></article>`).join('');
 const o=A.filter(a=>st[a.id]!='done').length;$('#asub').textContent=o?o+' butuh tindakan':'Semua sudah ditangani';$('#empty').style.display=l.length?'none':'block';
 $$('.act button').forEach(b=>b.onclick=()=>{const i=+b.dataset.i,a=b.dataset.a;if(a=='done'){st[i]=st[i]=='done'?'':'done';toast(st[i]?'Ditandai ditangani':'Dibuka kembali')}else if(a=='ex')st[i]=st[i]=='ex'?'':'ex';else askLaras('Jelaskan: '+A.find(x=>x.id==i).t);alerts()})}
$$('#filt button').forEach(b=>b.onclick=()=>{flt=b.dataset.f;$$('#filt button').forEach(x=>x.classList.toggle('on',x==b));alerts()});
$('#dprev').onclick=()=>setDate(addD(DATE,-1));$('#dnext').onclick=()=>setDate(addD(DATE,1));$('#dtoday').onclick=()=>setDate(TODAY);$('#dpick').onchange=e=>setDate(e.target.value);
draw();alerts();
